from flask import Flask, request, jsonify
from flask_cors import CORS
import os
from huggingface_hub import login, whoami
from transformers import AutoTokenizer, AutoModelForCausalLM

# Login to Hugging Face
token = "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"  # Replace with your token
login(token=token)

# Verify login
user_info = whoami()
print(f"Logged in as {user_info['name']}")

# Load the model and tokenizer
model_id = "manoj2423/Llama-2-7b-chat-finetune"
tokenizer = AutoTokenizer.from_pretrained(model_id)

offload_folder = "./offload"
os.makedirs(offload_folder, exist_ok=True)

model = AutoModelForCausalLM.from_pretrained(
    model_id,
    torch_dtype="auto",
    device_map="auto",
    offload_folder=offload_folder
)

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Allow cross-origin requests

@app.route("/chat", methods=["POST"])
def chat():
    try:
        # Get user input from the request
        data = request.json
        user_input = data.get("input", "")

        # Process input with the model
        inputs = tokenizer(user_input, return_tensors="pt").to(model.device)
        output = model.generate(**inputs, max_new_tokens=50)
        response = tokenizer.decode(output[0], skip_special_tokens=True)

        # Return the model response
        return jsonify({"response": response})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
