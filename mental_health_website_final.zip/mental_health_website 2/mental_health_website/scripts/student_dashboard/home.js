document.addEventListener("DOMContentLoaded", function () {
    // Example quote functionality
    const quoteElement = document.getElementById("quote");
    const quotes = [
        "Believe in yourself!",
        "You are stronger than you think.",
        "Your only limit is your mind.",
    ];
    const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
    quoteElement.textContent = randomQuote;
});
