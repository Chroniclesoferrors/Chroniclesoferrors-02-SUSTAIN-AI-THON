let unlockedDays = 1;

function completeExercise(day) {
    alert(`You have completed the exercise for Day ${day}!`);

    // After completing the exercise, unlock the next day
    unlockNextDay();
}

function unlockNextDay() {
    if (unlockedDays < 100) {
        unlockedDays++;
        enableDayExercise(unlockedDays);
    }
}

function enableDayExercise(day) {
    const dayElement = document.querySelector(`#day${day}`);
    const startBtn = dayElement.querySelector('.start-btn');
    
    dayElement.querySelector('h2').textContent = `Day ${day}`;
    
    // Enable the button to start the exercise
    startBtn.disabled = false;
    
    startBtn.onclick = function() {
        completeExercise(day);
    };
}

window.onload = function() {
    for (let i = 1; i <= unlockedDays; i++) {
        enableDayExercise(i);
    }
};
