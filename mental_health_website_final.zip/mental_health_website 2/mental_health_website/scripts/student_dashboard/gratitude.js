let unlockedDays = 1;

function saveEntry(day) {
    const entryPoints = document.querySelectorAll(`#day${day} .entry-point`);
    let entries = [];
    
    entryPoints.forEach((point) => {
        if (point.value.trim()) {
            entries.push(point.value.trim());
        }
    });

    if (entries.length > 0) {
        localStorage.setItem(`day${day}`, JSON.stringify(entries));
        alert("Your gratitude entries have been saved!");
    } else {
        alert("Please write at least one gratitude entry.");
    }
}

function unlockNextDay() {
    if (unlockedDays < 100) {
        unlockedDays++;
        enableDayEntry(unlockedDays);
    }
}

function enableDayEntry(day) {
    const dayElement = document.querySelector(`#day${day}`);
    const saveBtn = dayElement.querySelector('.save-btn');
    const entryPoints = dayElement.querySelectorAll('.entry-point');
    
    dayElement.querySelector('h2').textContent = `Day ${day}`;
    
    // Enable text inputs
    entryPoints.forEach((input) => input.disabled = false);
    
    // Enable save button
    saveBtn.disabled = false;
    saveBtn.classList.add('enabled');
    
    dayElement.classList.add('unlocked');
    
    saveBtn.onclick = function() {
        saveEntry(day);
        unlockNextDay();  // Unlock next day automatically
    };
}

window.onload = function() {
    for (let i = 1; i <= unlockedDays; i++) {
        enableDayEntry(i);
    }
};
