let unlockedDays = 1;

function saveEntry(day) {
    const textarea = document.querySelector(`#day${day} textarea`);
    const entry = textarea.value;
    
    if (entry) {
        localStorage.setItem(`day${day}`, entry);
        alert("Your journal entry has been saved!");
    } else {
        alert("Please write something to save.");
    }
}

function unlockNextDay() {
    if (unlockedDays < 100) {
        unlockedDays++;
        enableDayEntry(unlockedDays);
    }
}

function enableDayEntry(day) {
    const dayElement = document.querySelector(`#day${day}`);
    const saveBtn = dayElement.querySelector('.save-btn');
    
    dayElement.querySelector('h2').textContent = `Day ${day}`;
    saveBtn.disabled = false;
    saveBtn.classList.add('enabled');
    dayElement.classList.add('unlocked');
    
    saveBtn.onclick = function() {
        saveEntry(day);
        unlockNextDay();  // Unlock next day automatically
    };
}

window.onload = function() {
    for (let i = 1; i <= unlockedDays; i++) {
        enableDayEntry(i);
    }
};

