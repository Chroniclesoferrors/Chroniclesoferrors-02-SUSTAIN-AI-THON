document.addEventListener('DOMContentLoaded', () => {
    // Get references to the elements
    const chatbotButton = document.querySelector('.chatbot-btn');
    const chatbotPopup = document.getElementById('chatbot-popup');
    const sendButton = document.getElementById('send-button');
    const userMessageInput = document.getElementById('user-message');
    const messagesContainer = document.querySelector('.messages');

    // Toggle the chatbot visibility
    chatbotButton.addEventListener('click', () => {
        chatbotPopup.style.display = chatbotPopup.style.display === 'none' || chatbotPopup.style.display === '' ? 'block' : 'none';
    });

    // Handle send button click
    sendButton.addEventListener('click', () => {
        const message = userMessageInput.value.trim();
        if (message) {
            const messageDiv = document.createElement('div');
            messageDiv.classList.add('user-message');
            messageDiv.textContent = message;
            messagesContainer.appendChild(messageDiv);
            userMessageInput.value = '';
            messagesContainer.scrollTop = messagesContainer.scrollHeight; // Scroll to bottom
        }
    });

    // Optionally, you can add a keypress event to send the message when the Enter key is pressed
    userMessageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendButton.click();
        }
    });
});
