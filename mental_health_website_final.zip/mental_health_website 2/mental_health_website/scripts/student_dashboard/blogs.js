document.addEventListener("DOMContentLoaded", function () {
    // Example behavior for blog page (fetching articles, etc.)
    const blogContainer = document.getElementById("blogs-container");

    const blogs = [
        {
            title: "The Power of Positive Thinking",
            content: "Learn how positive thinking can improve your mental health and outlook on life.",
        },
        {
            title: "Managing Stress Effectively",
            content: "Stress is a common challenge. Discover practical tips for managing stress.",
        },
    ];

    blogs.forEach(blog => {
        const article = document.createElement("article");
        const title = document.createElement("h3");
        title.textContent = blog.title;
        const content = document.createElement("p");
        content.textContent = blog.content;
        article.appendChild(title);
        article.appendChild(content);
        blogContainer.appendChild(article);
    });
});
