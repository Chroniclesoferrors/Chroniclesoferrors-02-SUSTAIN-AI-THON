document.addEventListener("DOMContentLoaded", function () {
    // Example behavior for peer interaction page (e.g., handling posts)
    const postButton = document.getElementById("post-button");
    const postContent = document.getElementById("post-content");
    const postsContainer = document.getElementById("posts-container");

    postButton.addEventListener("click", function () {
        const newPost = postContent.value.trim();
        if (newPost) {
            const postDiv = document.createElement("div");
            postDiv.classList.add("post");
            postDiv.textContent = newPost;
            postsContainer.appendChild(postDiv);
            postContent.value = "";
        }
    });
});
