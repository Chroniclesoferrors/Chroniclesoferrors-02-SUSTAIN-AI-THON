document.addEventListener("DOMContentLoaded", function () {
    // Example behavior for mission page (e.g., handling journaling, gratitude)
    const journalButton = document.getElementById("journal-button");
    const gratitudeButton = document.getElementById("gratitude-button");
    
    journalButton.addEventListener("click", function () {
        // Open a modal or new page for journaling
        alert("Start writing your journal here...");
    });

    gratitudeButton.addEventListener("click", function () {
        // Open a modal or new page for gratitude diary
        alert("Write something you are grateful for...");
    });
});
