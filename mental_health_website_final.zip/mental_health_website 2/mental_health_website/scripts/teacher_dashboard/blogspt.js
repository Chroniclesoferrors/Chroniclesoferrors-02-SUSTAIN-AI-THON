document.addEventListener("DOMContentLoaded", function () {
    // Example blogs for teachers/parents
    const blogContainer = document.getElementById("blogspt-container");

    const blogs = [
        {
            title: "Supporting Students' Mental Health",
            content: "Learn how to support students who are struggling with their mental health.",
        },
        {
            title: "Building Emotional Resilience",
            content: "Tips for building emotional resilience in children and teens.",
        },
    ];

    blogs.forEach(blog => {
        const article = document.createElement("article");
        const title = document.createElement("h3");
        title.textContent = blog.title;
        const content = document.createElement("p");
        content.textContent = blog.content;
        article.appendChild(title);
        article.appendChild(content);
        blogContainer.appendChild(article);
    });
});
