document.addEventListener("DOMContentLoaded", function () {
    // Progress tracking for teacher/parent
    const progressContainer = document.getElementById("progresspt-container");

    const studentProgress = {
        grades: 85,
        attendance: 90,
        assignmentsCompleted: 75,
    };

    progressContainer.innerHTML = `
        <p>Grades: ${studentProgress.grades}%</p>
        <p>Attendance: ${studentProgress.attendance}%</p>
        <p>Assignments Completed: ${studentProgress.assignmentsCompleted}%</p>
    `;
});
