document.addEventListener("DOMContentLoaded", function () {
    // Teacher/Parent dashboard specific logic
});
