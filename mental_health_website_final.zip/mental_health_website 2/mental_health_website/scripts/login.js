document.getElementById("login-form").addEventListener("submit", function (event) {
    event.preventDefault();

    // Get user data from form
    const userType = document.getElementById("user-type").value;
    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();

    // Validate input
    if (!username || !password) {
        alert("Please fill in all fields.");
        return;
    }

    // Collect data
    const userData = {
        userType: userType,
        username: username,
        password: password,
    };

    // Convert data to JSON
    const dataStr = JSON.stringify(userData, null, 2);
    const blob = new Blob([dataStr], { type: "application/json" });

    // Create a download link for the JSON file
    const downloadLink = document.getElementById("download-link");
    downloadLink.href = URL.createObjectURL(blob);
    downloadLink.download = `${username}_data.json`;

    // Make the download link visible
    downloadLink.classList.remove("hidden");

    // Show the download container
    const downloadContainer = document.getElementById("download-container");
    downloadContainer.classList.remove("hidden");

    // Navigate to the appropriate dashboard
    if (userType === "student") {
        // Redirect to student dashboard
        window.location.href = "student_dashboard/home.html";
    } else if (userType === "teacher") {
        // Redirect to teacher dashboard
        window.location.href = "teacher_dashboard/homept.html";
    }

    // Clear the form
    document.getElementById("login-form").reset();

    // Show an alert to confirm successful login
    alert("Login successful. Download your data.");
});

// Navigation logic for sub-pages
function navigate(pageId) {
    const allPages = document.querySelectorAll(".sub-page");
    allPages.forEach(page => page.classList.add("hidden"));

    const targetPage = document.getElementById(pageId);
    if (targetPage) {
        targetPage.classList.remove("hidden");
    }
}

// Initialize default visible page
document.addEventListener("DOMContentLoaded", function () {
    // Ensure the login page is visible on load
    document.getElementById("login-page").classList.add("active");
});
